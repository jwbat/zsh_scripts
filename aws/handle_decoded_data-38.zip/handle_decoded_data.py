import json
import psycopg2
from collections import defaultdict
import psycopg2.extras
from psycopg2.pool import SimpleConnectionPool
import boto3
from botocore.exceptions import ClientError


GLOBAL_SECRET_NAME = "GlobalUBXCRDB"
LOCAL_CLUSTER_SECRET_NAMES = [
    'ProdUBXCRDB',
    'StagingUBXCRDB',
    'DevUBXCRDB',
    'TestUBXCRDB',
]
DEV_CLUSTER_SECRET_NAMES = [
    'PatsCRDB',
    'WmsCRDB',
]


class ConnectionContext:
    def __init__(self, name, parent, dict_cursor=True):
        self.parent = parent
        self.name = name
        self.dict_cursor = dict_cursor

    def __enter__(self):
        self.conn = self.parent.get_connection(self.name)
        if self.dict_cursor:
            self.cur = self.conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        else:
            self.cur = self.conn.cursor()
        return self.cur

    def __exit__(self, exc_type, exc_value, exc_tb):
        self.cur.close()

        if exc_type is None:
            self.conn.commit()

        self.parent.put_connection(self.name, self.conn)
        if exc_type is not None:
            return False

class DBHandler:
    def __init__(self, region):
        self.region = region
        self.boto_session = boto3.session.Session()
        self.pools = {}
        self.secrets_client = self.boto_session.client(
            service_name='secretsmanager',
            region_name=region)

    def get_secret(self, secret_name):
        try:
            secret_value_response = self.secrets_client.get_secret_value(
                SecretId=secret_name)
        except ClientError as e:
            # for a list of exceptions thrown, see
            # https://docs.aws.amazon.com/secretsmanager/latest/apireference/API_GetSecretValue.html
            raise e
        # decrypt secret using the associated KMS key.
        return secret_value_response['SecretString']

    def get_dsn_from_secret(self, secret_name):
        return json.loads(self.get_secret(secret_name))['DSN']

    def connect(self, secret_name):
        return ConnectionContext(secret_name, self)

    def get_connection(self, secret_name):
        if secret_name not in self.pools:
            dsn = self.get_dsn_from_secret(secret_name)
            print(f'Connecting to {dsn}')
            self.pools[secret_name] = SimpleConnectionPool(0, 1, dsn)

        pool = self.pools[secret_name]
        conn = pool.getconn()
        if not conn:
            raise Exception(f'Unable to get connection to {secret_name}')

        return conn

    def put_connection(self, secret_name, conn):
        if secret_name in self.pools:
            self.pools[secret_name].putconn(conn)
        else:
            print(f'Error: no pool found for {secret_name} in put_connection()')




class Topic:
    """
    In the future we may desire more complex topics with additional keys.
    This provides a central location to map intention to implementation.
    """
    topic_keys = {
        'dev_eui'
        }

    topic_template = 'ubx/data_change/{dev_eui}'

    @classmethod
    def fill_topic_keys(cls, **kwargs):
        return {k:kwargs.get(k,'+') for k in cls.topic_keys}

    @classmethod
    def format_topic(cls, **kwargs):
        kwargs = cls.fill_topic_keys(**kwargs)
        return cls.topic_template.format(**kwargs)

    @classmethod
    def from_dev_eui(cls, dev_eui):
        return cls.format_topic(dev_eui=dev_eui)

class DataChangeHandler():

    def __init__(self, region_name = 'us-west-2'):
        self.client = boto3.client('iot-data', region_name=region_name)

    def get_topic(self, payload):
        return Topic.from_dev_eui(payload['dev_eui'])

    @staticmethod
    def pack_payload(dev_eui, known_asset_uuid, stamp, property_name, value):
        payload = {
            'dev_eui': dev_eui,
            'known_asset_uuid': known_asset_uuid,
            'stamp': stamp,
            'property': property_name,
            'value': value
            }
        return payload

    def _publish(self, topic, payload):
        response = self.client.publish( topic = topic, qos=1,
                                        payload = json.dumps(payload)
                                        )
        return response

    def publish_single(self, dev_eui, known_asset_uuid, stamp, property_name, value):
        """
        publish a data change for a singla property.
        """
        payload = self.pack_payload(dev_eui, known_asset_uuid, stamp, property_name, value)
        topic = self.get_topic(payload)
        response = self._publish(topic, [payload])
        return response

    def publish_many(self, dev_eui, known_asset_uuid, stamp, data):
        """
        publish multiple data changes for a single device.
        data is a dictionary mapping property_name: value
        """
        payloads = defaultdict(list)
        for property_name, value in data.items():
            entry = self.pack_payload(dev_eui, known_asset_uuid, stamp, property_name, value)
            topic = self.get_topic(entry)
            payloads[topic].append(entry)

        responses = []
        for topic, payload in payloads.items():
            response = self._publish(topic, payload)
            responses.append(response)

        return responses


class LambdaHandler(DBHandler):
    def __init__(self, region):
        super(LambdaHandler, self).__init__(region)
        self.ka_cache = {}
        self.data_change_handler = DataChangeHandler(region)

    def get_ka_uuid(self, dev_eui):
        if not dev_eui in self.ka_cache.keys():
            try:
                with self.connect(GLOBAL_SECRET_NAME) as cur:
                    cur.execute("""
                         SELECT r.known_asset_uuid FROM
                         ubx_device_registry r
                         WHERE r.serial_number=%s;""",
                         (dev_eui,))
                    row = cur.fetchone()
                    self.ka_cache[dev_eui] = row['known_asset_uuid']
            except Exception as e:
                print(f'Failed to retrieve known_asset_uuid for {dev_eui}')
                raise

        return self.ka_cache[dev_eui]

    def update_database(self, lorawan, decoded_message):
        dev_eui = lorawan['DevEui']
        gconn = self.get_connection(GLOBAL_SECRET_NAME)
        try:
            with gconn.cursor() as cur:
                cur.execute(
                    'INSERT INTO ubx_device_data_cache(dev_eui,properties,stamp) '+
                    'VALUES(%s,%s,%s::TIMESTAMPTZ);',
                    (dev_eui, json.dumps(decoded_message), lorawan['Timestamp']))

                gconn.commit()
            # put the data into the global cluster's property state table. Eventually this will be the only
            # place it goes.
            # The argument list has sets of three values for each key:value pair in the
            # decoded result: property name, property value (a JSONB string), and time stamp.
            # The latter two must eventually be cast in the query.
            # The last argument is the dev_eui, which is used to look up the registry_uuid
            # which is needed for each value tuple.
            args = []
            for k, v in decoded_message.items():
                args.append(k)
                args.append(json.dumps({k:v}))
                args.append(lorawan['Timestamp'])
            args.append(dev_eui)
            with gconn.cursor() as cur:
                cur.execute(
                    'UPSERT INTO ubx_device_property_state (registry_uuid, property_name, property_value, update_stamp)'+
                    'SELECT reg.registry_uuid, vals.name, vals.value, vals.stamp '+
                    'FROM ubx_device_registry reg '
                    'CROSS JOIN (VALUES '+
                    ','.join(["(%s,%s::JSONB,%s::TIMESTAMPTZ)"] * len(decoded_message))+
                    ') AS vals(name, value, stamp) '+
                    'WHERE reg.serial_number = %s;',
                    args)
                gconn.commit()
        finally:
            self.put_connection(GLOBAL_SECRET_NAME, gconn)

    def send_data_changes(self, dev_eui, ka_uuid, stamp, payload):
        try:
            stamp = datetime.strptime(stamp, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc).timestamp()

            self.data_change_handler.publish_many(  dev_eui = dev_eui,
                                                    known_asset_uuid = ka_uuid,
                                                    stamp = stamp,
                                                    data = payload,
                                                    )


        except Exception as e:
            print(f'send data changes failed: {e}')


    def handler(self, event, decode):
        lorawan = event['WirelessMetadata']['LoRaWAN']
        deveui = lorawan['DevEui']
        ka_uuid = self.get_ka_uuid(deveui)
        print(f'Handling {deveui} with {ka_uuid=}')
        payload = decode(event['PayloadData'], ka_uuid)
        gateways = lorawan['Gateways'][:]
        gateways.sort(key=lambda x:-x['Rssi'])
        payload['rssi'] = gateways[0]['Rssi']
        payload['best_gateway_eui'] = gateways[0]['GatewayEui']
        payload['gateways'] = gateways
        if payload:
            self.update_database(lorawan, payload)
            self.send_data_changes(deveui, ka_uuid, lorawan['Timestamp'], payload)
        else:
            #print(' payload: ', payload, ' fport: ', fport, ' deveui: ', deveui )
            print(' payload: ', payload, ' deveui: ', deveui )

